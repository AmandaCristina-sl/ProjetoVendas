﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ProjetoVenda.Model
{
    internal class Product
    {
        public int cod_produto;
        public int cod_funcionario;
        public string nome;
        public string marca;
        public int preco;
        public int quantidade;
        public DateTime data_registro;
    }
}
