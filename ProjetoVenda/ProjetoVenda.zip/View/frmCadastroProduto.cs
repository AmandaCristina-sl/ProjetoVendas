﻿using ProjetoVenda.Controller;
using ProjetoVenda.Model;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;


namespace ProjetoVenda.View
{
    public partial class frmCadastroProduto : Form
    {
        private ProductController controller;

        public frmCadastroProduto()
        {
            InitializeComponent();
            controller = new ProductController();
        }

        private void btnCadastroProduto_Click(object sender, EventArgs e)
        {
            string nome = this.txtNome.Text;
            string marca = this.txtMarca.Text;
            int preco = Convert.ToInt32(this.txtPreco.Text);
            int quantidade = Convert.ToInt32(this.txtQuantidade.Text);

            // Emcapsulado os dados
            Product product = new Product
            {
                nome = nome,
                marca = marca,
                preco = preco,
                quantidade = quantidade
            };
            // Enviar os dados para Controller
            bool resp = controller.createProduct(product);
            if (resp)

            {
                MessageBox.Show("Produto Cadastrado Com Sucesso",
                    "CADASTRO PRODUTO",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );

            }
            else
            {
                MessageBox.Show("Erro ao Cadastrar Produto",
                    "CADASTRO PRODUTO",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        private void frmCadastroProduto_Load(object sender, EventArgs e)
        {
            // finalizar a lista de produtos
            List<Product> list = controller.getAll();
            dgvProdutos.DataSource = list;
        }
    }
}
